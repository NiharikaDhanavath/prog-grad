#!/bin/bash

# Check if a prefix is provided as an argument
if [ "$#" -eq 0 ]; then
    echo "Usage: $0 <directorypath> <prefix>"
    exit 1
fi

prefix=$2
directory_path=$1  # Change this to the actual directory path

# Check if the specified path is a directory
if [ ! -d "$directory_path" ]; then
    echo "Error: '$directory_path' is not a directory."
    exit 1
fi

# Add the prefix to all files in the directory
for file in "$directory_path"*; do
    if [ -f "$file" ]; then
        base_name=$(basename "$file")
        new_name="$directory_path/$prefix$base_name"
        mv "$file" "$new_name"
        echo "Renamed: $file to $new_name"
    fi
done

echo "File renaming completed successfully."
