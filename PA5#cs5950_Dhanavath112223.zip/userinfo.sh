#!/bin/bash

# Check if a username is provided as an argument
if [ $# -eq 0 ]; then
    echo "Usage: $0 <username>"
    exit 1
fi

username=$1

# Check if the user exists
if id "$username" &>/dev/null; then
    # User information
    full_name=$(getent passwd "$username" | cut -d ':' -f 5 | cut -d ',' -f 1)
    home_directory=$(getent passwd "$username" | cut -d ':' -f 6)
    shell_type=$(getent passwd "$username" | cut -d ':' -f 7)

    # Display user information
    echo "User Information for: $username"
    echo "Full Name: $full_name"
    echo "Home Directory: $home_directory"
    echo "Shell Type: $shell_type"
else
    echo "User '$username' does not exist."
fi

