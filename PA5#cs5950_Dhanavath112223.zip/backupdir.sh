#!/bin/bash

# Check if a directory path is provided as an argument
if [ "$#" -ne 1 ]; then
    echo "Usage: $0 <directory_path>"
    exit 1
fi

directory_path=$1

# Check if the provided path is a directory
if [ ! -d "$directory_path" ]; then
    echo "Error: '$directory_path' is not a directory."
    exit 1
fi

# Create a backup file with the current date in the filename
backup_filename="backup_$(date "+%Y%m%d").tar.gz"

# Specify the backup location (change this path accordingly)
backup_location="/root/backup/"

# Create a compressed backup of the entire directory
tar -czvf "$backup_location/$backup_filename" -C "$directory_path" .

echo "Backup completed successfully. Backup file: $backup_location/$backup_filename"
