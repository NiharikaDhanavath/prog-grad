#!/bin/bash

# Current date and time
current_date_time=$(date "+%Y-%m-%d %H:%M:%S")

# System uptime
uptime_info=$(uptime)

# Total number of users currently logged in
logged_in_users=$(who | wc -l)

# Memory usage
memory_info=$(free -h | awk 'NR==2{printf "Used: %s, Free: %s", $3, $4}')

# Disk usage
disk_info=$(df -h / | awk 'NR==2{printf "Used: %s, Free: %s", $3, $4}')

# Display system information
echo "System Health Check Report"
echo "---------------------------"
echo "Date and Time: $current_date_time"
echo "Uptime: $uptime_info"
echo "Logged-in Users: $logged_in_users"
echo "Memory Usage: $memory_info"
echo "Disk Usage: $disk_info"
