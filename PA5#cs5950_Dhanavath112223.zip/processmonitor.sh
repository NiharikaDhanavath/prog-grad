#!/bin/bash

# Check if a process name is provided as an argument
if [ "$#" -eq 0 ]; then
    echo "Usage: $0 <process_name>"
    exit 1
fi

process_name=$1

# Check if the process is running
if pgrep -x "$process_name" > /dev/null; then
    # If the process is running, log memory and CPU usage
    echo "Process '$process_name' is already running."
    memory_usage=$(pmap $(pgrep -x "$process_name") | grep total | awk '{print $2}')
    cpu_usage=$(ps -p $(pgrep -x "$process_name") -o %cpu | tail -n 1)
    echo "Memory Usage: $memory_usage KB"
    echo "CPU Usage: $cpu_usage%"
else
    # If the process is not running, start the process and log the event
    echo "Process '$process_name' is not running. Starting the process..."
    $process_name 
    echo "Process '$process_name' started."
fi
