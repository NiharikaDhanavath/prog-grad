#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 12345
#define BUFFER_SIZE 1024

void error(const char *msg) {
    perror(msg);
    exit(EXIT_FAILURE);
}

int main() {
    int sockfd;
    struct sockaddr_in server_addr, client_addr;
    socklen_t client_len = sizeof(client_addr);
    char buffer[BUFFER_SIZE];

    // Create UDP socket
    if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) == -1) {
        error("Error creating socket");
    }

    // Initialize server address struct
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(PORT);

    // Bind socket to port
    if (bind(sockfd, (struct sockaddr *)&server_addr, sizeof(server_addr)) == -1) {
        error("Error binding socket");
    }

    while (1) {
        // Receive data from client
        int bytes_received = recvfrom(sockfd, buffer, sizeof(buffer), 0,
                                      (struct sockaddr *)&client_addr, &client_len);
        if (bytes_received == -1) {
            error("Error receiving data");
        }

        // Print received integers
        printf("Received integers: ");
        for (int i = 0; i < bytes_received / sizeof(int); i++) {
            int value;
            memcpy(&value, &buffer[i * sizeof(int)], sizeof(int));
            printf("%d ", value);
        }
        printf("\n");

        // Print current system time
        time_t current_time = time(NULL);
        printf("Received at: %s", ctime(&current_time));
    }

    close(sockfd);
    return 0;
}
