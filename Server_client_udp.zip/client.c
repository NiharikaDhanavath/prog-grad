#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <arpa/inet.h>

#define SERVER_IP "127.0.0.1"
#define PORT 12345
#define BUFFER_SIZE 1024
#define DELAY_SECONDS 10

void error(const char *msg) {
    perror(msg);
    exit(EXIT_FAILURE);
}

int main() {
    int sockfd;
    struct sockaddr_in server_addr;
    char buffer[BUFFER_SIZE];

    // Create UDP socket
    if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) == -1) {
        error("Error creating socket");
    }

    // Initialize server address struct
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = inet_addr(SERVER_IP);
    server_addr.sin_port = htons(PORT);

    // Open the file for reading
    FILE *file = fopen("hw6input.txt", "rb");
    if (!file) {
        error("Error opening file");
    }

    // Read and send data in chunks
    int value;
    while (fread(&value, sizeof(int), 1, file) > 0) {
        // Print the value before sending
        printf("Sending value: %d\n", value);

        // Copy the value to the buffer
        memcpy(buffer, &value, sizeof(int));

        // Send data to server
        if (sendto(sockfd, buffer, sizeof(int), 0, (struct sockaddr *)&server_addr,
                   sizeof(server_addr)) == -1) {
            error("Error sending data");
        }

        // Print current system time
        time_t current_time = time(NULL);
        printf("Sent at: %s", ctime(&current_time));

        // Wait for the specified delay
        sleep(DELAY_SECONDS);
    }

    fclose(file);
    close(sockfd);
    return 0;
}
