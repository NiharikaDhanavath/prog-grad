Steps to run the code:
===============================================================================
Changing the directory cd /home/niharika/

To Compile the ./udp_client file

$ gcc client.c -o udp_client

To Compile the ./udp_server file

$ gcc server.c -o udp_server

===============================================================================

To Start the Server

$ ./udp_server

=================================================================================

To Start the client

$ ./udp_client

==================================================================================

To run the script.sh file
$./script.sh

 To kill the socket to start a new one
$ fuser -k -n udp 12345

========================================================================================


