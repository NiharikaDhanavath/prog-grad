./udp_server &

gcc client.c -o client

./client >> client.log

gcc client1.c -o client1

./client1 >> client1.log